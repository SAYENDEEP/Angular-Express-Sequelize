const express =require("express");
const Sequelize=require("sequelize");
const app=express();
const db2= require("./db.config");
var cors=require('cors');
app.use(cors());
var sequelize= new Sequelize(db2.DB,db2.USER,db2.PASSWORD,{
   host:db2.HOST,
   dialect:db2.dialect,
   pool:{
       max:db2.pool.max,
       min:db2.pool.min,
       acquire:db2.pool.acquire,
       idle:db2.pool.idle
   }
});
let LoginRegisterTable2= sequelize.define('LoginRegisterTable2',{
        Firstname :{
            primaryKey:true,
            type:Sequelize.STRING
        },
        Lastname:Sequelize.STRING,
        Phoneno:Sequelize.STRING,
        Emailno:Sequelize.STRING,
        Password:Sequelize.STRING,
        Location:Sequelize.STRING
       
    },{
        timestamps:false,
        freezeTableName:true
});
// LoginRegisterTable2.sync({force:true}).then(()=>{
//     console.log("Table Created successfully");
// }).catch(err=>{
//      console.log("Error in Creation"+err);
// })
app.use(express.json());
app.post('/register',(req,res)=>{
    // console.log(req.body);
    var Firstname=req.body.Firstname;
    var  Lastname=req.body.Lastname;
    var Phoneno =req.body.Phoneno;
    var Emailno=req.body.Emailno;
    var Password=req.body.Password;
    var Location=req.body.Location;
    // console.log(Firstname,Lastname,Phoneno);
     var UserObj=LoginRegisterTable2.build({Firstname:Firstname,Lastname:Lastname,Phoneno:Phoneno,Emailno:Emailno,Password:Password,Location:Location})
     UserObj.save().then(()=>{
         console.log("User Register Successfully");
         res.status(201).send("User Registered Successfully");
     }).catch((err)=>{
         console.log(err);
         res.status(400).send("User Not Registered Successfully");
     })
})
app.post('/login',(req,res)=>{
    var email=req.body.email;
    var  password=req.body.password;
    console.log(email,password);
    const Op=Sequelize.Op;
    LoginRegisterTable2.findAll({raw:true}).then((data)=>{
       var flag=0;
       console.log(data.length);
        for(var i=0;i<data.length;i++){
            console.log(data[i]);
            if(data[i].Emailno==email&& data[i].Password==password )
              {
                  flag=1;
                  break;
              }
        }
        if(flag==1){
            console.log("User Login Successful");
            res.status(201).send("User Login Successful");
        }else{
           console.log("User Login UnSuccessful");
           res.status(201).send("User Login UnSuccessful");  
        }
       }).catch((err)=>{
           console.log("Error Encountered");
           res.status(400).send("Error Occured");
       })
    })
app.listen(8001,function(){
    console.log("Server is listening");
})





