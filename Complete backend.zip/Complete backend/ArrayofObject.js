const express= require('express')
var cors=require('cors');
const app=express();
app.use(express.json());
app.use(cors()); 
const Employee=[
    {id:1,name:"sayendeep",dept:"cse",designation:"Full stack"},
    {id:2,name:"tarun",dept:"IT",designation:"Software engineer"},
    {id:3,name:"rohit",dept:"MECH",designation:"Junior Consultant"},
    {id:4,name:"bharat",dept:"Civil",designation:"Senior Consultant"}
]
app.get('/getAllEmployeeData',(req,res)=>{
    console.log("Sending array of object");
 
    res.send(Employee);
})
app.get('/getEmployeeById/:Id',(req,res)=>{
    var id= req.params.Id;
       for(var i=0;i<Employee.length;i++){
           if(Employee[i].id==id)
           {
               res.send(Employee[i]);
           }
       }
    res.send("Your required id is:-"+id);
})
app.get('/getEmployeeByName/:name',(req,res)=>{
    var name1= req.params.name;
      for(var i=0;i<Employee.length;i++){
          if(Employee[i].name=name1){
              res.send(Employee[i]);
          }
      }
})
app.post('/insertEmployeeData',(req,res)=>{
       Employee.push(req.body);
       res.send("Inserted Successfully");
})
app.put('/updateEmployeeData',(req,res)=>{
    console.log(req.body);
   var IDs=req.body.id;
   console.log(IDs);
   
     var index=-1;
    for(let i=0;i<Employee.length;i++){
     if(Employee[i].id==IDs)
      {
          index=i;
          break;
      }
    }
    if(index==-1)
      res.send("Unable to update");
    else{ 
      Employee[index]=req.body;
      res.send("Successfully updated");
    }

     
})
app.delete('/deleteRecord/:ID',(req,res)=>{
     var Id1=req.params.ID;
     var flag=-1;
     for(let i=0;i<Employee.length;i++){
         if(Employee[i].id==Id1){
             flag=i;
             break;
         }
     }
     if(flag==-1){
         res.send("Record not present");
     }else{
        Employee.splice(flag,1);
        res.send("Deleted successfully");
     }
})
app.listen(8003,function(){
    console.log("Server is running");
})

// const express= require('express')
// const app=express();
// app.use(express.json());

// app.post('/totalsalary',(req,res)=>{
//   var Basic=req.body.Basic;
//   var HRA=req.body.HRA;
//   var DA=req.body.DA;
//   var IT=req.body.IT;
//   var PF=req.body.PF;
//   var total_salary = Basic + HRA + DA - (IT + PF);
//   console.log("Your Total salary is "+total_salary);
//   res.send("Your Salary is Calculated succesfully"+total_salary);
// })
// app.listen(8000,function(){
//     console.log("Server is running");
// })