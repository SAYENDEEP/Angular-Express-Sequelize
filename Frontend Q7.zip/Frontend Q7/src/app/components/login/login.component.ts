import { Component, OnInit } from '@angular/core';
import {FormBuilder,FormGroup,Validator, Validators,FormControlName, FormControl} from "@angular/forms"
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import {LoginregisterService} from '../../services/loginregister.service'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public loginForm!:FormGroup;
  constructor(private formBuidler:FormBuilder,private http:HttpClient,private router:Router,private LoginregisterService:LoginregisterService) { }

  ngOnInit(): void {
    this.loginForm=this.formBuidler.group({
      email:['',[Validators.required,Validators.email]],
      password:['',[Validators.required,Validators.minLength(6)]]
  })
}
username:any;

loginUser(){
  this.LoginregisterService.loginUser(this.loginForm.value).subscribe
  (
    (data)=>
    {
      alert(data);
      console.log(JSON.stringify(data));
    },
    (error)=> console.log("Error encountered")
  );
 }


}
