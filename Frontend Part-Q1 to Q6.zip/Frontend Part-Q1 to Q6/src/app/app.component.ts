import { Component } from '@angular/core';
import { LoginService } from './services/login.service';
import { FormBuilder,FormControl, FormGroup } from '@angular/forms';
import { EmployeeService } from './services/employee.service';

import { PolicyService } from './services/policy.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Frontendpart';
    public loginform!:FormGroup;
    public SalaryCal!:FormGroup;
    public Policyform!:FormGroup;
  constructor(private LoginUser:LoginService,private FormBuilder:FormBuilder,private EmployeeUser:EmployeeService,private PolicyUser:PolicyService){};
   
  ngOnInit(){
      this.loginform=this.FormBuilder.group({
         username:[''],
         password:['']
      })
      this.SalaryCal=this.FormBuilder.group( {
           Basic:[''],
           HRA:[''],
           DA:[''],
           IT:[''],
           PF:['']
        }
      )
      this.Policyform=this.FormBuilder.group( {
        PolicyNumber:[''],
        PolicyHoldersName:[''],
        PolicyAmt:[''],
        MaturityAmount:[''],
        Nominee:['']
     }
   )
  }

  username="";
  password="";
  loginUser(){
     this.LoginUser.validUser(this.loginform.value).subscribe
     (
       (data)=>
       {
         alert(data);
         console.log(JSON.stringify(data));
       },
       (error)=> console.log("Error encountered")
     );
    }
   arrEmployee:any=[];
   getAllEmployeeData(){
     this.EmployeeUser.getAllEmployeeData1().subscribe(
        (data)=>{
            console.log("Data recieved successfully");
            this.arrEmployee=data;
        },
        (error)=>console.log("Error Encountered")
      
      ) 
   }
   total_salary:any;
  calSalary(){
    this.EmployeeUser.calSalary1(this.SalaryCal.value).subscribe(
      (data)=>{
           console.log("Data recieved Successfully");
           this.total_salary=data;
           alert("Total Salary:-"+data);
      },
      (error)=> console.log("Error Encountered")
    )
  }
  empid=0;
  getEmployeeId(){
    this.EmployeeUser.getAllEmployeeDataById(this.empid).subscribe
    (
      (data)=>
      {
        alert("Id is "+data.id+" Name is "+data.name+" Department is "+data.dept+" Designation is" +data.designation);
        console.log("Received data :"+JSON.stringify(data));

      },
      (error)=>console.log("Error Encountered")
    );
  }
  names="";
  getEmployeeName(){
    this.EmployeeUser.getAllEmployeeDataByName(this.names).subscribe
    (
      (data)=>
      {
        alert("Id is "+data.id+" Name is "+data.name+" Department is "+data.dept+" Designation is" +data.designation);
        console.log("Received data :"+JSON.stringify(data));

      },
      (error)=>console.log("Error Encountered")
    );
  }
  insertEmployee()
  {
    let empObj={"id":5,"name":"Colan","dept":"CSE","designation":"Developer"};
    this.EmployeeUser.insertEmployee(empObj).subscribe(
      (data)=>{
        alert(data);
        console.log("Inserted data is "+ JSON.stringify(data));
      },
      (error)=> console.log("Unabled to insert record because"+error)
    );
  } 
  updateEmployee(){
    let empObj={"id":4,"name":"Mohit","dept":"IT","designation":"Developer"};
    this.EmployeeUser.updateEmployee(empObj).subscribe(
      (data)=>{
        alert("Data updated successfully");
        
      },
      (error)=>console.log("Unabled to Update the data")
      );
  }
  empid1=0;
  deleteEmployee()
  {
    this.EmployeeUser.deleteEmployee(this.empid1).subscribe
    (
      (data)=>{
        console.log("Data returned from delete() is"+JSON.stringify(data));
        alert(data);
      },
      (error)=> console.log('Unabled to delete record because'+JSON.stringify(error))
  
    )
  }
  arrPolicy:any=[];
  getAllPolicyData(){
    this.PolicyUser.getAllPolicyData().subscribe(
       (data)=>{

           this.arrPolicy=data;
           alert("Data recieved successfully");
       },
       (error)=>console.log("Error Encountered")
     
     ) 
  }
  policyId=0;
  getPolicyById(){
    this.PolicyUser.getAllPolicyDataById(this.policyId).subscribe
    (
      (data)=>
      {
        alert("Id is "+data.id+" Name is "+data.name+" Department is "+data.dept+" Designation is" +data.designation);
        console.log("Received data :"+JSON.stringify(data));

      },
      (error)=>console.log("Error Encountered")
    );
  }
  insertPolicy()
  {
    let PolicyObj={"PolicyNumber":5,"PolicyHoldersName":"Poraan","PolicyAmt":100050,"MaturityAmount":503,"Nominee":"Dakter"};
    this.PolicyUser.insertPolicy(PolicyObj).subscribe(
      (data)=>{
        alert(data);
        console.log("Inserted data is "+ JSON.stringify(data));
      },
      (error)=> console.log("Unabled to insert record because"+error)
    );
  }
  updatePolicy(){
    let PolicyObj={"PolicyNumber":4,"PolicyHoldersName":"Pava","PolicyAmt":106050,"MaturityAmount":1020,"Nominee":"Mitali"};
    this.PolicyUser.updatePolicyData(PolicyObj).subscribe(
      (data)=>{
        alert("Data updated successfully");
        
      },
      (error)=>console.log("Unabled to Update the data")
      );
  }
  policyId1=0;
  deletePolicy()
  {
    this.PolicyUser.deletePolicy(this.policyId1).subscribe
    (
      (data)=>{
        console.log("Data returned from delete() is"+JSON.stringify(data));
        alert(data);
      },
      (error)=> console.log('Unabled to delete record because'+JSON.stringify(error))
  
    )
  }
}

