import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private http:HttpClient) { }

  URL1="http://localhost:8003";
  

  getAllEmployeeData1():Observable<any>
  {
      var URL= this.URL1+"/getAllEmployeeData";
      return this.http.get(URL);
  }
  getAllEmployeeDataById(id:any):Observable<any>
  {
   
        var URL=this.URL1+"/getEmployeeById/"+id;
        console.log(URL);
        return this.http.get(URL);
  }
  insertEmployee(empObj:any):Observable<any>
  {
        var URL=this.URL1+"/insertEmployeeData";
        let header ={'content-type':'application/json'};

        return this.http.post(URL,empObj,{'headers':header,responseType:'text'});
  }
  getAllEmployeeDataByName(name1:any):Observable<any>
  {
   
        var URL=this.URL1+"/getEmployeeByName/"+name1;
        console.log(URL);
        return this.http.get(URL);
  } 
  updateEmployee(empObj:any):Observable<any>
  {
    var URL=this.URL1+"/updateEmployeeData";

    let header ={'content-type':'application/json'}
    return this.http.put(URL,empObj,{'headers':header,'responseType':'text'});

  }
  deleteEmployee(id:any):Observable<any>
  {
    var URL=this.URL1+"/deleteRecord/"+id;
    return this.http.delete(URL,{responseType:'text'});

  }
  URL2="http://localhost:8002";
  calSalary1(caldata:any):Observable<any>
  {
    var URL3=this.URL2+"/totalsalary";
    var body=caldata;
      
    let header={'content-type':'application/json'};
    return this.http.post(URL3,body,{'headers':header,'responseType':'text'});
  }
 
}
